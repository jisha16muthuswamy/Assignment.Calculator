﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using LoreSoft.MathExpressions.Properties;

namespace LoreSoft.MathExpressions
{
    internal class CustomFunctionExpression : ExpressionBase
    {
        /// <summary>The supported math operators by this class.</summary>
        public static readonly string[] OperatorSymbols = new string[] { "sqrt" };

        /// <summary>Initializes a new instance of the <see cref="OperatorExpression"/> class.</summary>
        /// <param name="operator">The operator to use for this class.</param>
        /// <exception cref="ArgumentNullException">When the operator is null or empty.</exception>
        /// <exception cref="ArgumentException">When the operator is invalid.</exception>
        public CustomFunctionExpression(string @operator)
        {
            if (string.IsNullOrEmpty(@operator))
                throw new ArgumentNullException("operator");


            switch (@operator)
            {
                case "sqrt":
                    base.Evaluate = new MathEvaluate(CalculateSquareRoot);                    
                    break;

                default:
                    throw new ArgumentException(Resources.InvalidOperator + @operator, "operator");
            }

        }

        public double CalculateSquareRoot(double[] numbers)
        {    
            Validate(numbers);
            return SquareRootEvaluator.Evaluate(numbers[0]);
        }

        protected new void Validate(double[] numbers)
        {
            base.Validate(numbers);
            double firstValue = numbers[0];
            if (firstValue < 0)
            {
                throw new ArgumentException("Cannot compute the square root of a negative number.");
            }
        }

        /// <summary>Gets the number of arguments this expression uses.</summary>
        /// <value>The argument count.</value>
        public override int ArgumentCount
        {
            get { return 1; }
        }

        /// <summary>Determines whether the specified function name is a function.</summary>
        /// <param name="function">The function name.</param>
        /// <returns><c>true</c> if the specified name is a function; otherwise, <c>false</c>.</returns>
        public static bool IsCustomSqrtFunction(string function)
        {
            return  OperatorSymbols.Contains( function);
        }

    }
   
    internal static class SquareRootEvaluator
    {
        /// <summary>
        /// Calculates the square root
        /// </summary>
        /// <param name="number">The number to clculate square root</param>
        /// <returns> square root of the input</returns>
        public static double Evaluate(double number)
        {
            double root = 1;
            int i = 0;
            //The Babylonian Method for Computing Square Roots
            while (true)
            {
                i = i + 1;
                root = (number / root + root) / 2;
                if (i == number + 1) { break; }
            }
            return root;
    }
    }

}
