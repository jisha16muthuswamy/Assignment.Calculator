﻿Install-ChocolateyPackage 'Calculator.Net' 'msi' '/quiet' 'https://github.com/loresoft/Calculator/releases/download/1.2.0.0/Calculator.v1.2.0.0.msi'
