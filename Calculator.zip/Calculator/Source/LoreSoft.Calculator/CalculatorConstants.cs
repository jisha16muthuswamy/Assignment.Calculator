namespace LoreSoft.Calculator
{
    internal static class CalculatorConstants
    {
        public const string WindowsCalculatorName = "calc.exe";
    }
}
